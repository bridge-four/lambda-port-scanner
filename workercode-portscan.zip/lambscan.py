#!/usr/bin/python
import json
import socket
import urllib3

def port_scan(host, proto, port):
   s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
   s.settimeout(1)
   #result = False
   result = s.connect_ex((host,port))
   s.close()
   if result == 0:
      return True
   else :
      return False

def lambda_handler(event, context):
    http = urllib3.PoolManager()
    resp = http.request('GET', 'http://checkip.amazonaws.com')
    source_ip = resp.data.decode('utf-8').strip()

    host = event['host']
    proto = event['proto']
    port = event['port']
    
    result = port_scan(host, proto, port)
    
    return {
        'statusCode': 200,
        'body': result,
        'source_ip': source_ip
    }

