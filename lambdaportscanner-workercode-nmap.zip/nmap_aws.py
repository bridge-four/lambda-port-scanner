import subprocess
import os
import urllib3
import logging

logger = logging.getLogger('custom_logger')
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    nmap_args = event['args'].split()
    target = event['target']
    outfile = "/tmp/" + target

    # Get source IP
    try:
        http = urllib3.PoolManager()
        resp = http.request('GET', 'http://checkip.amazonaws.com', retries=10, timeout=5)
        source_ip = resp.data.decode('utf-8').strip()
        print("SOURCE_IP:", str(source_ip))
    except Exception as e:
        print('Source IP check connection failed:', e)

    # Run nmap
    cmd = ['./nmap'] + nmap_args + target.split() + ["-oA"] + outfile.split()
    out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(out.stdout.decode())

    # Format and get output from disk
    output_gnmap = ""
    output_nmap = ""
    output_xml = ""
    try:
        with open(f"{outfile}.gnmap", "r") as file:  
            output_gnmap = file.read() 
        with open(f"{outfile}.nmap", "r") as file:  
            output_nmap = file.read() 
        with open(f"{outfile}.xml", "r") as file:  
            output_xml = file.read() 
    except Exception as e:
        print("Error reading data files...", e)
    return {
        'statusCode': 200,
        'body': out.stdout.decode(),
        'source_ip': source_ip,
        'target' : target,
        'output_gnmap' : output_gnmap,
        'output_nmap' : output_nmap,
        'output_xml' : output_xml,
    }
